# mSig - R software for processing and analyzing mutational signatures

The code is decribed in Ng et al., 2017, "Aristolochic acids and their derivatives are widely 
implicated in liver cancers in Taiwan and throughout Asia", Science Translational Medicine  18 Oct 2017, 9:412, eaan6446,
DOI: 10.1126/scitranslmed.aan6446. 
